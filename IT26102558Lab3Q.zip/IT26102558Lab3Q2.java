import java.util.Scanner;

public class IT26102558Lab3Q2 {

   public static void main (String[] args) {
	   
	Scanner input = new Scanner(System.in);
    double MonthlySalary, OTHours, OTHourlyRate, OTAmount, TotalSalary;

	System.out.print("Enter the monthly salary:");
	MonthlySalary = input.nextDouble();

    System.out.print("Enter the number of OT hours:");
    OTHours = input.nextDouble();

    System.out.print("Enter the OT hourly rate:");
    OTHourlyRate = input.nextDouble();

	OTAmount = OTHours * OTHourlyRate;
	TotalSalary = MonthlySalary + OTAmount;
	
	System.out.print("the total salary including OT is = " + TotalSalary);
	
	input.close();
	
	 
   }



}	