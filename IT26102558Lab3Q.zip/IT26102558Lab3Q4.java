import java.util.Scanner;

public class IT26102558Lab3Q4 {
	
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter a five digit number:");
		int n = input.nextInt();
		
	    System.out.println (n/10000+ " " +
		                   (n/1000) % 10 + " " +
						   (n/100) % 10 + " " +
						   (n/10) % 10 + " " +
						   n % 10 
						   );
		input.close();				   
		
		
		
	}
	
}