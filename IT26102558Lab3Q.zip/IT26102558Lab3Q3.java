import java.util.Scanner;

public class IT26102558Lab3Q3 {
	public static void main(String[] args) {
	
    Scanner input = new Scanner(System.in);	
	
	System.out.print("Enter the Rupee amount: ");
	int Amount = input.nextInt();
	
	System.out.println("5000 Notes - 0");
	Amount = Amount % 5000;
	
	System.out.println("1000 Notes - 2");
	Amount = Amount % 1000;
	
	System.out.println("500 Notes - 1");
	Amount = Amount % 500;
	
	System.out.println("200 Notes - 1");
	Amount = Amount % 200;
	
	System.out.println("100 Notes - 0");
	Amount = Amount % 100;
	
	System.out.println("50 Notes - 1");
	Amount = Amount % 50;
	
	System.out.println("20 Notes - 0");
	Amount = Amount % 20;
	
	System.out.println("10 Notes - 0");
	Amount = Amount % 10;
	
	System.out.println("05 Notes - 0");
	Amount = Amount % 05;
	
	System.out.println("02 Notes - 0");
	Amount = Amount % 02;
	
	System.out.println("01 Notes - 0");
	Amount = Amount % 01;
	
	

	input.close();
		
		
		
	}
	
}