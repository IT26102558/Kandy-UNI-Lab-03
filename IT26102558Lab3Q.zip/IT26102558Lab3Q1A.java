import java.util.Scanner;

public class IT26102558Lab3Q1A {
    public static void main(String[] args){

     Scanner input = new Scanner(System.in);
	 double price, kg, amount;
	
	 System.out.print("Enter the price of 1kg of rice: ");
	 price = input.nextDouble();
	
	 System.out.print("Enter the number of kilograms you want to buy:");
	 kg = input.nextDouble();
	
	 amount = price * kg;
	
	 System.out.print("The total amount is = " + amount);
	
	 input.close();
	 


    } 
} 	